//
//  UserDefaults.swift
//  Study Guide
//
//  Created by Erick Sanchez on 11/1/21.
//

import Foundation

class UserDefaultsStore {

    // TODO: Store key-value pairs
    
    // TODO: Read key-value pairs
    
    // TODO: Delete keys
    
}
